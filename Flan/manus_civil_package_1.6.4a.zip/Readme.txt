Package Readme
-------------------------------------------------------------------------------
Name:				Manus Civil Package

Version-No.:			1.6.4a
-------------------------------------------------------------------------------
Author:				Manus

Contact:			www.minecraft-smp.de
-------------------------------------------------------------------------------
Mc-Version:			1.6.4

Flans Mod Version:		4.0

Depencies:			Minecraft-SMP Parts Package 1.6.4b

Build with Forge Version:	1.6.4-9.11.1.916
-------------------------------------------------------------------------------
This Package is free to download on www.minecraft-smp.de. 

If you downloaded it somewhere else or payed for it (single or as part of a
compilation) please report this to manus@minecraft-smp.de.